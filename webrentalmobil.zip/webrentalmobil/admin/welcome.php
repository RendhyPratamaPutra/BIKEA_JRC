<style type="text/css">
	.welcome{
		background-color: #eaeaea;
		padding: 50px;
	}
</style>
<div class="welcome">
	<h1>Selamat datang Administrator</h1>
	<p>Halaman ini digunakan untuk mengelola data Jember Rent Car</p>
</div>