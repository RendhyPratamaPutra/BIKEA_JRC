<?php 
	include 'proses.php';

	$koneksi = mysqli_connect("localhost","root","","jrc");

	if (isset($_POST['submit'])) {
		$merek = $_POST['merek'];
		$namaMobil = $_POST['namaMobil'];
		$tahun = $_POST['tahun'];
		$warna = $_POST['warna'];
		$kursi = $_POST['kursi'];
		$plat = $_POST['plat'];
		$lokasi_file=$_FILES['gambar']['tmp_name'];
		$nama_file=$_FILES['gambar']['name'];
		move_uploaded_file($lokasi_file,"../gambar/$nama_file");

		$result =mysqli_query($koneksi, "UPDATE mobil INNER JOIN harga ON mobil.id=merek.mobil SET merek='$merek', namaMobil='$namaMobil', tahun='$tahun', warna='$warna', kursi='$kursi' WHERE mobil.id='$id'");
	}

		//edit harga
		$id = $_GET['id'];
		$result =mysqli_query($koneksi, "SELECT * FROM mobil INNER JOIN kategori ON mobil.id=merek.mobil WHERE mobil.id='$id'");
		while($row = mysqli_fetch_array($result)) {
			$merek = $row['merek'];
			$namaMobil = $row['namaMobil'];
			$tahun = $row['tahun'];
			$warna = $row['warna'];
			$kursi = $row['kursi'];
			$plat = $row['plat'];
			$lokasi_file=$_FILES['gambar']['tmp_name'];
			$nama_file=$_FILES['gambar']['name'];
			move_uploaded_file($lokasi_file,"../gambar/$nama_file");
		}

		//tambah harga

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Daftar Mobil</title>
</head>
<body>
	<h1>Daftar Mobil</h1>

	<form action="" method="post">
		<label for="kategori">Merek : </label>
		<td>
		<select name="merek">
								<?php
								foreach ($do->selectMerek() as $val) {
									echo "<option value='$val[0]'>$val[1]</option>";
								}
								?>
		</select></td>><br>
		<label for="mobil">Nama Mobil : </label>
		<input type="" name="nama" value=<?php echo $nama;?>>
		<br>
		<label for="tahun">Tahun : </label>
		<input type="text" name="tahun" value=<?php echo $tahun;?>>
		<br>
		<label for="warna">Warna : </label>
		<input type="text" name="warna" value=<?php echo $warna;?>>
		<br>
		<label for="kursi">Kursi : </label>
		<input type="text" name="kursi" value=<?php echo $kursi;?>>
		<br>
		<label for="plat">Plat : </label>
		<input type="text" name="plat" value=<?php echo $plat;?>>
		<br>
		<input type="hidden" value=<?php echo $_GET['id'] ; ?> name="id">
		<button name="update">Simpan</button>
	</form>
</body>
</html>